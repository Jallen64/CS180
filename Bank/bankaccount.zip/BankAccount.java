import java.util.ArrayList;
import java.util.Random;


public class BankAccount {
    //instance variables
    private int accountNumber;
    private String name;
    private double balance;

    //static properties
    private static double interest = 0.3;
    private static ArrayList<BankAccount> accounts = new ArrayList<BankAccount>();

    //The first constructor receives a name and creates bank account with balance = 0
    public  BankAccount (String name) {
        //TODO 1.1
    }

    //The second constructor receives name and balance, creates a bank amount and updates balance
    public BankAccount (String name, double balance) {
        //TODO 1.2
    }

    //This method performs deposit operation
    public double deposit(double money) {
        //TODO 2
    }

    //This method performs withdraw operation
    public double withdrawMoney(double money) {
        //TODO 3
    }

    //This method returns account number
    public int getAccountNumber() {
        //TODO 4
    }

    //This method returns interest rate
    public static double getInterestRate() {
        //TODO 5
    }

    //This method performs a transfer operation to a single bank account
    public double transfer(BankAccount destinationBankAccount, double amount) {
        //TODO 6
    }

    //This method performs a transfer operation to multiple accounts
    public double transfer(BankAccount[] destinationBankAccount, double amount) {
        //TODO 7
    }

    public static void main(String args[]) {
        //Feel free to add code that will help you test your methods
    }
}